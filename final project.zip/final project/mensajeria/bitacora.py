"""Bitácora JSONL: un mensaje completo por línea, persistido antes de confirmar."""
import json
import os
import threading
from pathlib import Path


class Bitacora:
    def __init__(self, ruta: Path) -> None:
        self.ruta = ruta
        ruta.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        # Una caída durante una escritura podría dejar una última línea parcial.
        # Se preserva su contenido y se separa de los nuevos registros.
        with ruta.open("a+b") as archivo:
            if archivo.tell():
                archivo.seek(-1, os.SEEK_END)
                if archivo.read(1) != b"\n":
                    archivo.seek(0, os.SEEK_END)
                    archivo.write(b"\n")
                    archivo.flush()
                    os.fsync(archivo.fileno())

    def guardar(self, mensaje: dict[str, object]) -> None:
        linea = (json.dumps(mensaje, ensure_ascii=False) + "\n").encode("utf-8")
        with self._lock, self.ruta.open("ab") as archivo:
            archivo.write(linea)
            archivo.flush()
            os.fsync(archivo.fileno())
